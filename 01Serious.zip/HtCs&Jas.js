window.addEventListener('DOMContentLoaded', ()=>{

    console.log("All tags interprited")

    let bu = document.querySelector("#bu")
    

    bu.addEventListener('click', ()=>{

        let tbx = document.querySelector("#tbx").value
        let check = callEvenOrOdd(tbx)

        if(check)
        {
            
            console.log("Button Clicked")

            let msg = document.querySelector("#msg")

            msg.classList.remove("b")
            msg.classList.add("a")

            document.querySelector("#msg").innerText = "The Number is Even"
         
        }
        else
        {

            console.log("Button Clicked")

            let msg = document.querySelector("#msg")

            msg.classList.remove("a")
            msg.classList.add("b")
            
            document.querySelector("#msg").innerText = "The Number is Odd"

        }

    })
    


        function callEvenOrOdd(input)
        {
            return ((input % 2) == 0)
        }


})

/* Note: - classlist is used to utilize the style of class of CSS where remove and add is used to change color of text. */
           