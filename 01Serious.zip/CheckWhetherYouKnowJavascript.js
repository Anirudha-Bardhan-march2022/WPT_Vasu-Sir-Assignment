let x = document.querySelector("#x");             // Event Registered on x by assigned to x variable


// Event handling by addEventListener on x for id x

x.addEventListener('click',()=>{                 //here by click on x event is handling

    console.log('Event is occured by click on OK button');                //shows output on developer console


});


/*   Note: # is used to give reference here for x of html id.
           Double carefull when you use name because is very much case sensitive.
           Where are using "" or ''.   */