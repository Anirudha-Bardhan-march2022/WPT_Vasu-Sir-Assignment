let x = document.querySelector("#x");

x.addEventListener('click', ()=>{

    console.log("Add button is clicked");

    let firstnumber = document.querySelector("#t1").value;
    let secondnumber = document.querySelector("#t2").value;
    let result = parseInt(firstnumber) + parseInt(secondnumber);

    console.log("Addition is "+""+result);
    document.querySelector("#msg").innerText="Add result is "+result;     

});


/*    Note: Input taking by Value from html id to Javascript variable
            parseInt() is used for converting string to int  */
