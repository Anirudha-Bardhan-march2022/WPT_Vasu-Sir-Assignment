window.addEventListener('DOMContentLoaded', ()=>{

    console.log("All tags interprited")

    let bu = document.querySelector("#bu")
    

    bu.addEventListener('click', ()=>{

                
        let radios = document.getElementsByName('radios')
        
        for(let i of radios)
        {
        
            if(i.checked)
            {

            console.log("Make Red Button Clicked")

            let h = document.querySelector("#h")

            h.classList.remove("u")
            h.classList.add("r")

            break
         
            }else{

            console.log("Make Underline Button Clicked")

            let h = document.querySelector("#h")

            h.classList.remove("r")
            h.classList.add("u")

            break
            
            }

        }



    })
    


        
})

/* Note:- group of radio buttons can be operated with getElementsByName('')
          by for-of loop we can operate radio buttons alternatively with if - else and break statements */