window.addEventListener('DOMContentLoaded', ()=>{

    console.log("All tags are interprited")

    let bu = document.querySelector("#bu")

    bu.addEventListener('click', ()=>{

    let tx = document.getElementById("tx").value
    
    let sentence = tx.toUpperCase()

    document.querySelector("#ty").value = sentence
    document.querySelector("#msg").innerText = tx

    console.log(sentence)


    })


})

/*    Note: The text message of one text box show to another text box by using placeholder as above 
            for presenting the message into upper case is used toUpperCase()*/