window.addEventListener('DOMContentLoaded', ()=>{

let addorUpdateorDeletedone = false;

  let x=[11,12,13,14,15,16,17,18,19,20];

  //assume this comes from the server...


  //setting up blur event on the textbox.

  const t1 =document.querySelector("#t1");

  t1.addEventListener('blur', ()=>{
	
		let numberGiven = document.querySelector("#t1").value;

		let found = checkNumberinArray(numberGiven);


		if(!found)
		{
			
			document.querySelector("#add").disabled=false;
			document.querySelector("#edit").disabled=true;
			document.querySelector("#delete").disabled=true;
			document.querySelector("#viewAll").disabled=true;
			document.querySelector("#viewoddpositions").disabled=true;
			document.querySelector("#msg").innerText="Add new number";
				
		}
		else
		{
			document.querySelector("#msg").innerText="number aleady present";
			document.querySelector("#add").disabled=true;
			document.querySelector("#edit").disabled=false;
			document.querySelector("#delete").disabled=false;
			document.querySelector("#viewAll").disabled=true;
			document.querySelector("#viewoddpositions").disabled=true;
			
		}
		
		if(addorUpdateorDeletedone)
		{
		
		document.querySelector("#viewAll").disabled=false;
			document.querySelector("#viewoddpositions").disabled=false;
		
		}



});



//add button event handlder

const add =document.querySelector("#add");

add.addEventListener('click',()=>{

addorUpdateorDeletedone=true;

let numberGiven = document.querySelector("#t1").value;

let output=addtoArray(numberGiven);           // true if added, returns false

if(output)
document.querySelector("#msg").innerText="number added";
else
document.querySelector("#msg").innerText="number not added";


			document.querySelector("#add").disabled=true;
			document.querySelector("#edit").disabled=true;
			document.querySelector("#delete").disabled=true;
			document.querySelector("#viewAll").disabled=true;
			document.querySelector("#viewoddpositions").disabled=true;
			
		
		if(addorUpdateorDeletedone)
		{
		
		document.querySelector("#viewAll").disabled=false;
			document.querySelector("#viewoddpositions").disabled=false;
		
		}


});                      //end of add event handler



const edit =document.querySelector("#edit");

edit.addEventListener('click',()=>{

console.log("modify is working");

addorUpdateorDeletedone=true;

let numberGiven = document.querySelector("#t1").value;

let replacemenetNumber = window.prompt("enter new number");       //learn new function on need basis.

let output=updateArray(numberGiven,replacemenetNumber);

if(output)
document.querySelector("#msg").innerText="number modified";
else
document.querySelector("#msg").innerText="number not modified";


			document.querySelector("#add").disabled=true;
			document.querySelector("#edit").disabled=true;
			document.querySelector("#delete").disabled=true;
			document.querySelector("#viewAll").disabled=true;
			document.querySelector("#viewoddpositions").disabled=true;

if(addorUpdateorDeletedone)
{
		
	document.querySelector("#viewAll").disabled=false;
	document.querySelector("#viewoddpositions").disabled=false;
		
}



});                         //end of event handling for edit (update)




const deletebutton =document.querySelector("#delete");

deletebutton.addEventListener('click',()=>{

console.log("delte function getting called");

addorUpdateorDeletedone=true;

let numberGiven = document.querySelector("#t1").value;

let output=removeFromArray(numberGiven);

if(output)
document.querySelector("#msg").innerText="number removed";
else
document.querySelector("#msg").innerText="number not found";


			document.querySelector("#add").disabled=true;
			document.querySelector("#edit").disabled=true;
			document.querySelector("#delete").disabled=true;
			document.querySelector("#viewAll").disabled=true;
			document.querySelector("#viewoddpositions").disabled=true;
			
		if(addorUpdateorDeletedone)
		{
		
		document.querySelector("#viewAll").disabled=false;
			document.querySelector("#viewoddpositions").disabled=false;
		
		}


});                                             //end of delete logic



const viewAll =document.querySelector("#viewAll");

viewAll.addEventListener('click',()=>{

console.log("view all event handling");

let output=getArrayContents();

document.querySelector("#contents").innerText=output;



});



const viewoddpositions =document.querySelector("#viewoddpositions");

viewoddpositions.addEventListener('click',()=>{

console.log("view odd positions event handling");

let output=getArrayContentsFromOdd();

document.querySelector("#contents").innerText=output;



});




  
  function getArrayContentsFromOdd()
  {
  let contents = "";
		for(let i=0; i < x.length; i++)
	    {
		    if( i%2 != 0)
			    contents += " " + x[i];
        }


   return contents;
	
  
  }


  
  function getArrayContents()
  {
	let contents = "";

		for(let i=0; i < x.length; i++)
	    {
			contents += " " + x[i];
        }


   return contents;


   	
  }
  


  function updateArray(numberGiven,replacemenetNumber)
  {
	let updated = false;

	if(!checkNumberinArray(replacemenetNumber))
	{
		for(let i=0; i < x.length; i++)
        {

		if(x[i]==numberGiven)
		{
		   x[i]=replacemenetNumber;
		   updated = true;
		   break;
		   
		}
   
        }
		
	}

    
	return updated;


  
  }



  
  function addtoArray(numbergiven)
  {
  let added= true;
  x.push(numbergiven);
  return added;
  
  }


  
  function removeFromArray(numberGiven)
  {
  
  let removed =false;
  let index=-1;
   for(let i=0; i < x.length; i++)
   {
		if(x[i]==numberGiven)
		{
		   index =i;
		   break;
		   
		}
   
   }

   if(index >= 0)
   {
	x.splice(index,1);          //index position, how many elements to remove
	removed=true;
   
   }
  
  
  return removed;
  
  
  
  }


  
  function checkNumberinArray(numbertoCheck)
  {
	let found = false;
   
   for(let i=0; i < x.length; i++)
   {
		if(x[i]==numbertoCheck)
		{
		   found = true;
		   break;
		   
		}
   
   }


   return found;
  
  }





  



});