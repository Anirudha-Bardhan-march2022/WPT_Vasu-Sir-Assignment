const express = require('express')
const app = express()


//app.use(express.static('cp')) 

app.get('/addItem', (x,y)=>{

    y.send('add item needs to be done')


})


app.get('/updateItem', (x,y)=>{

    y.send('updateItem needs to be done')

    
})


app.listen(90, ()=>{

    console.log("server listening on port 90.....")

    
})