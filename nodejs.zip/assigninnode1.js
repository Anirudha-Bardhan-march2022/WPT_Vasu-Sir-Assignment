const http = require('http') 
const url = require('url')

http.createServer((x,y)=>{

    let radius = url.parse(x.url, true).query
    let output = multiple(radius.a)
    
    console.log("callback function called")

    y.write("Hello Server the diameter is"+" "+output)
    y.end()

    function multiple(radius)
    {
        let output = radius * 2                  
        
        return output

    }


}).listen(800) 