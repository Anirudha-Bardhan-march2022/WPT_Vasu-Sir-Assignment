function previousNumber(x)
{

    return x-= 1

}


let x = previousNumber(100)

console.log("Previous Number is"+" "+x)